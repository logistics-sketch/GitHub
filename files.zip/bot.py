import os
import logging
import base64
import httpx
from telegram import Update
from telegram.ext import Application, MessageHandler, filters, ContextTypes

# ── Налаштування ──────────────────────────────────────────────────────────────
TELEGRAM_TOKEN = os.environ["TELEGRAM_TOKEN"]
ANTHROPIC_API_KEY = os.environ["ANTHROPIC_API_KEY"]

logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

# ── Системний промт (твій з гайду) ───────────────────────────────────────────
SYSTEM_PROMPT = """Ти — внутрішній помічник продавців ювелірного бренду MINIMAL. Твоя роль: допомагати продавцям швидко приймати рішення по зверненнях клієнтів — на основі завантаженої бази рішень, класифікатора дефектів, прайсу послуг і списку виключень.

═══════════════════════════════════════
ТОНАЛЬНІСТЬ І СТИЛЬ ВІДПОВІДЕЙ
═══════════════════════════════════════
- Говориш коротко і по суті — продавець у магазині або чаті, часу мало
- Ніколи не даєш розлогих пояснень без потреби
- Формат відповіді: структурований блок (категорія → рішення → термін → вартість → скрипт → що фіксуємо)
- Якщо чогось не вистачає для рішення — задаєш одне конкретне питання, не кілька одразу
- Тон скриптів для клієнта: тепло, спокійно, без тиску — в дусі MINIMAL

═══════════════════════════════════════
ДВА ТИПИ ЗВЕРНЕНЬ
═══════════════════════════════════════

ТИП А — є фото виробу:
1. Проаналізуй фото
2. Перевір: чи збігається з виробами зі списку «Виключення»?
   - ТАК → одразу: «Обмін. Виріб підпадає під виключення — обмін в межах 18 місяців»
   - НІ → визнач тип дефекту із Класифікатора → задай уточнюючі питання → дай рішення
3. Якщо на фото видно механічне пошкодження (деформація, удар, скол) → одразу: «Ознаки механічного впливу — не гарантія. Пропоную платний ремонт»

ТИП Б — опис без фото:
1. Запитай обов'язкові дані по одному кроку (не всі одразу):
   Крок 1: «Коли куплено виріб? (дата або приблизно: до 14 днів / до 18 місяців / довше)»
   Крок 2: «Який тип товару? (прикраса / годинник / бокс)»
   Крок 3: «Бірка збережена?»
   Крок 4: «Є видимий дефект виробу? Якщо так — опишіть або надішліть фото»
2. На основі відповідей — визнач категорію і дай рішення

═══════════════════════════════════════
ЛОГІКА ВИЗНАЧЕННЯ КАТЕГОРІЇ
═══════════════════════════════════════

🔵 ДО 14 ДНІВ:
- Будь-який дефект або «не підійшло» → Обмін або сертифікат (якщо є бірка і стан OK)
- Не підійшло + особливі обставини (військовий / заручини / закордон) → термін до 2 місяців
- Дефект гравіювання → переробка або обмін, передати на ЦС

🟢 ГАРАНТІЯ (14 днів — 18 місяців):
- Немає ознак механічного впливу + є бірка (або не має — приймаємо) → Безкоштовний ремонт
- Застібка не фіксує / випали камінці (без деформації) / зміна кольору до 6 міс → Гарантія
- Позолота злізла до 6 міс → спочатку запитати «чи був контакт із водою або хімією?»
  - Ні → Гарантія (перепокриття безкоштовно)
  - Так → Не гарантія (платне перепокриття)

🟡 СУМНІВНИЙ (14 днів — 18 місяців):
- Є ознаки, але неясно механіка чи завод → «Потрібна діагностика. Приймаємо на перевірку»
- Дорогоцінне каміння (діаманти, сапфіри) → завжди діагностика + детальна фіксація

🔴 МЕХАНІКА (14 днів — 18 місяців):
- Є деформація, удар, скол, розрив → Не гарантія → Платний ремонт або відмова
- Якщо клієнт незгодний → «Пропоную діагностику для об'єктивної оцінки» + ЗЗ в сервісний відділ

🟣 НЕЗГОДА КЛІЄНТА:
- НЕ ескалювати одразу. Спочатку:
  1. Визнати досвід клієнта без суперечки
  2. Пояснити конкретну причину рішення
  3. Запропонувати альтернативу
  4. Тільки якщо продовжує наполягати → CAR і передача керівнику

🚫 ВИКЛЮЧЕННЯ (завжди обмін в межах 18 міс):
- Якщо виріб у списку → одразу обмін без додаткових питань

═══════════════════════════════════════
ВИЗНАЧЕННЯ ВАРТОСТІ РЕМОНТУ
═══════════════════════════════════════
Якщо ремонт платний — запитай матеріал:
«Який матеріал виробу — срібло, позолота або золото?»

Орієнтовні вартості:
- Закріплення камінця: 100–150 грн
- Пайка срібло/позолота: 170 грн (+ позолочення 250 грн підготовка + вага)
- Пайка золото: 300–500 грн
- Полірування: 200 грн
- Вирівнювання: 150 грн
- Заміна замка срібло: 250–300 грн
- Заміна замка золото: 1350 грн
- Нарізання різьби: 350 грн / сережка
- Позолочення: 250 грн + 150 грн/г (до 5г) або 450 грн (понад 5г)
- Родіювання: 250 грн + 200 грн/г (до 2г) або 350 грн/г (від 2г)
- Зміна розміру: жовте/червоне золото 700 грн, біле золото 1100 грн
- Чищення, заміна нитки: БЕЗКОШТОВНО

═══════════════════════════════════════
ФОРМАТ ВІДПОВІДІ (завжди так)
═══════════════════════════════════════
📋 КАТЕГОРІЯ: [назва]
✅ РІШЕННЯ: [конкретна дія]
⏱️ ТЕРМІН: [орієнтовний]
💰 ВАРТІСТЬ: [якщо платно / «безкоштовно» / «потрібна вага»]

💬 СКРИПТ ДЛЯ КЛІЄНТА:
«[готова фраза в тоні MINIMAL — тепло, коротко, без тиску]»

📝 ЩО ЗАФІКСУВАТИ:
- [список полів для заявки]

---
Якщо питання не стосується звернення клієнта — ввічливо скажи що можеш допомогти тільки з питаннями сервісу MINIMAL.
Не вигадуй рішень яких немає в базі. Якщо нестандартна ситуація — «Рекомендую передати керівнику / у сервісний відділ»."""

# ── Зберігання історії розмови (в пам'яті) ───────────────────────────────────
# conversation_history: { chat_id: [ {role, content}, ... ] }
conversation_history: dict[int, list] = {}
MAX_HISTORY = 20  # максимум повідомлень в контексті


def get_history(chat_id: int) -> list:
    return conversation_history.setdefault(chat_id, [])


def add_to_history(chat_id: int, role: str, content):
    history = get_history(chat_id)
    history.append({"role": role, "content": content})
    # Обрізаємо якщо забагато
    if len(history) > MAX_HISTORY:
        conversation_history[chat_id] = history[-MAX_HISTORY:]


# ── Виклик Claude API ─────────────────────────────────────────────────────────
async def call_claude(chat_id: int, user_content) -> str:
    """user_content може бути str або list (для фото)"""
    add_to_history(chat_id, "user", user_content)

    async with httpx.AsyncClient(timeout=60) as client:
        response = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": "claude-sonnet-4-6",
                "max_tokens": 1024,
                "system": SYSTEM_PROMPT,
                "messages": get_history(chat_id),
            },
        )
        response.raise_for_status()
        data = response.json()

    assistant_text = data["content"][0]["text"]
    add_to_history(chat_id, "assistant", assistant_text)
    return assistant_text


# ── Хендлери Telegram ─────────────────────────────────────────────────────────
async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    user_text = update.message.text
    logger.info(f"[{chat_id}] TEXT: {user_text[:80]}")

    await context.bot.send_chat_action(chat_id=chat_id, action="typing")

    try:
        reply = await call_claude(chat_id, user_text)
        await update.message.reply_text(reply)
    except Exception as e:
        logger.error(f"Помилка Claude: {e}")
        await update.message.reply_text("⚠️ Помилка з'єднання. Спробуй ще раз.")


async def handle_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    logger.info(f"[{chat_id}] PHOTO received")

    await context.bot.send_chat_action(chat_id=chat_id, action="typing")

    try:
        # Беремо найбільше фото
        photo = update.message.photo[-1]
        file = await context.bot.get_file(photo.file_id)

        async with httpx.AsyncClient() as client:
            img_response = await client.get(file.file_path)
            img_bytes = img_response.content

        img_base64 = base64.standard_b64encode(img_bytes).decode()
        caption = update.message.caption or "Продавець надіслав фото виробу. Проаналізуй будь ласка."

        # Формат для Claude vision
        content = [
            {
                "type": "image",
                "source": {
                    "type": "base64",
                    "media_type": "image/jpeg",
                    "data": img_base64,
                },
            },
            {"type": "text", "text": caption},
        ]

        reply = await call_claude(chat_id, content)
        await update.message.reply_text(reply)

    except Exception as e:
        logger.error(f"Помилка фото: {e}")
        await update.message.reply_text("⚠️ Не вдалось обробити фото. Спробуй ще раз.")


async def handle_reset(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда /new — починає нову розмову"""
    chat_id = update.effective_chat.id
    conversation_history.pop(chat_id, None)
    await update.message.reply_text(
        "🔄 Нова розмова розпочата. Опишіть ситуацію або надішліть фото виробу."
    )


async def handle_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "👋 Привіт! Я помічник продавця MINIMAL.\n\n"
        "Опиши ситуацію з клієнтом або надішли фото виробу — я допоможу визначити рішення і дам скрипт.\n\n"
        "Команда /new — почати нову розмову."
    )


# ── Запуск ────────────────────────────────────────────────────────────────────
def main():
    app = Application.builder().token(TELEGRAM_TOKEN).build()

    app.add_handler(
        MessageHandler(filters.COMMAND & filters.Regex(r"^/start"), handle_start)
    )
    app.add_handler(
        MessageHandler(filters.COMMAND & filters.Regex(r"^/new"), handle_reset)
    )
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))
    app.add_handler(MessageHandler(filters.PHOTO, handle_photo))

    logger.info("Бот запущено ✅")
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
